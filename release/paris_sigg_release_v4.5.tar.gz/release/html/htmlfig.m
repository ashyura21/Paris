function res=htmlfig(figpath)
  res=['<a href="' figpath '.pdf"><img style="border:solid 0px #000" src="' figpath '.jpg"/></a>'];
end
