% Author: Carl Doersch (cdoersch at cs dot cmu dot edu)
function dsfinishjob(mapredout,inds,idxstr,progressfile,completed,islast,mapredin)
  global ds;
  writeprogress=true;
%  idxstr=num2str(inds(:)');
  for(j=1:numel(mapredout))
    ['dssave ' mapredout{j} '{' idxstr '}']
    dssave([mapredout{j} '{' idxstr '}']);
    %TODO: get rid of this stuff when there's an error, too
    allpaths=dsexpandpath(mapredout{j});
    for(k=1:numel(allpaths))
      varnm=dsfindvar(allpaths{k});
      for(i=inds)
        %['(numel(' varnm ')>' num2str(i) ')&&~isempty(' varnm '{' num2str(i) '})']
        savedval=dsfield(varnm)&&eval(['(numel(' varnm ')>=' num2str(i) ')&&~isempty(' varnm '{' num2str(i) '})']);
        if(savedval)
          ds.sys.distproc.savedthisround(end+1)=struct('vars',allpaths{k},'inds',i);%[ds.sys.distproc.savedthisround{k} i];
          eval([varnm '{' num2str(i) '}=[]']);
          %dsload([allpaths{k} '{' num2str(i) '}']);
          %eval([varnm '{' num2str(i) '}=[]']);
          %ds.sys.distproc.savedthisround.inds(end+1)=i;%[ds.sys.distproc.savedthisround{k} i];
          %writeprogress=true;
        %else
        %  disp('fail')
        %  disp(varnm)
        %  disp(i)
          %disp(eval([varnm '{' num2str(i) '}']))
        %  savedval
        %  ['(numel(' varnm ')>' num2str(i) ')&&~isempty(' varnm '{' num2str(i) '})']
        %  eval(['~isempty(' varnm '{' num2str(i) '})'])
        %  eval(['(numel(' varnm ')>' num2str(i) ')']);
        end
      end
    end
  end
  for(j=1:numel(mapredin))
    allpaths=dsexpandpath(mapredin{j});
    for(k=1:numel(allpaths))
      varnm=dsfindvar(allpaths{k});
      for(i=inds)
        savedval=dsfield(varnm)&&eval(['iscell(' varnm ')&&(numel(' varnm ')>=' num2str(i) ')']);
        if(savedval)
          eval([varnm '{' num2str(i) '}=[]']);
        end
      end
    end
  end
  if(writeprogress && ~islast)
    cmd.savedthisround=ds.sys.distproc.savedthisround;
    cmd.completed=completed;
    save(progressfile,'cmd');
  end
end
